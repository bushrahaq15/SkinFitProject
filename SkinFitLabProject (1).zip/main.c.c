#include <stdio.h>
#include <string.h>

#define MAX_STEPS 10

// Define structure for routine
struct Routine
{
    char steps[MAX_STEPS][50];
    int count;
};

struct User
{
    char skinType[10];
    char timeOfDay[2];
    struct Routine routine;
};

// Function prototypes
void setRoutine(struct User *user);
void viewRoutine(struct User user);
void addStep(struct User *user);
void deleteStep(struct User *user);
void updateStep(struct User *user);
void searchStep(struct User user);
void saveRoutineToFile(struct User user);
void loadRoutineFromFile(struct User *user);

int main()
{
    struct User user;

    printf("Enter your skin type (Oily,Dry,Combination,Sensitive): ");
    scanf("%s", user.skinType);
    printf("Enter time (Day or Night): ");
    scanf("%s", user.timeOfDay);

    setRoutine(&user);
    loadRoutineFromFile(&user);

    int choice;
    do
    {
        printf("\n--- MENU ---\n");
        printf("1. View Routine\n");
        printf("2. Add Step\n");
        printf("3. Delete Step\n");
        printf("4. Update Step\n");
        printf("5. Search Step\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            viewRoutine(user);
            break;
        case 2:
            addStep(&user);
            break;
        case 3:
            deleteStep(&user);
            break;
        case 4:
            updateStep(&user);
            break;
        case 5:
            searchStep(user);
            break;
        case 0:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }
    }
    while (choice != 0);

    return 0;
}

// Basic skincare routine
void setRoutine(struct User *user)
{
    user->routine.count = 0;

    if (strcmp(user->skinType, "Oily") == 0)
    {
        if (strcmp(user->timeOfDay, "Day") == 0)
        {
            strcpy(user->routine.steps[0], "Gel cleanser");
            strcpy(user->routine.steps[1], "Oil-free moisturizer");
            strcpy(user->routine.steps[2], "Sunscreen (SPF 30+)");
            user->routine.count = 3;
        }
        else
        {
            strcpy(user->routine.steps[0], "Gel cleanser");
            strcpy(user->routine.steps[1], "Niacinamide serum");
            strcpy(user->routine.steps[2], "Lightweight night cream");
            user->routine.count = 3;
        }
    }
    else if (strcmp(user->skinType, "Dry") == 0)
    {
        if (strcmp(user->timeOfDay, "Day") == 0)
        {
            strcpy(user->routine.steps[0], "Cream cleanser");
            strcpy(user->routine.steps[1], "Hydrating toner");
            strcpy(user->routine.steps[2], "Moisturizer");
            strcpy(user->routine.steps[3], "Sunscreen");
            user->routine.count = 4;
        }
        else
        {
            strcpy(user->routine.steps[0], "Cream cleanser");
            strcpy(user->routine.steps[1], "Hyaluronic acid");
            strcpy(user->routine.steps[2], "Thick night cream");
            user->routine.count = 3;
        }
    }
    else if (strcmp(user->skinType, "Combination") == 0)
    {
        if (strcmp(user->timeOfDay, "Day") == 0)
        {
            strcpy(user->routine.steps[0], "Gentle foaming cleanser");
            strcpy(user->routine.steps[1], "Lightweight moisturizer");
            strcpy(user->routine.steps[2], "Sunscreen");
            user->routine.count = 3;
        }
        else
        {
            strcpy(user->routine.steps[0], "Foaming cleanser");
            strcpy(user->routine.steps[1], "Niacinamide + Hyaluronic acid");
            strcpy(user->routine.steps[2], "Gel-based night cream");
            user->routine.count = 3;
        }
    }
    else if (strcmp(user->skinType, "Sensitive") == 0)
    {
        if (strcmp(user->timeOfDay, "Day") == 0)
        {
            strcpy(user->routine.steps[0], "Gentle cleanser");
            strcpy(user->routine.steps[1], "Soothing toner");
            strcpy(user->routine.steps[2], "Fragrance-free moisturizer");
            strcpy(user->routine.steps[3], "Sunscreen");
            user->routine.count = 4;
        }
        else
        {
            strcpy(user->routine.steps[0], "Gentle cleanser");
            strcpy(user->routine.steps[1], "Aloe vera gel");
            strcpy(user->routine.steps[2], "Fragrance-free moisturizer");
            user->routine.count = 3;
        }
    }
}

// Save routine to file
void saveRoutineToFile(struct User user)
{
    FILE *file = fopen("routine.txt", "w");
    if (file == NULL)
    {
        printf("Error saving routine to file.\n");
        return;
    }
    fprintf(file, "%d\n", user.routine.count);
    for (int i = 0; i < user.routine.count; i++)
    {
        fprintf(file, "%s\n", user.routine.steps[i]);
    }
    fclose(file);
}

void loadRoutineFromFile(struct User *user)
{
    FILE *file = fopen("routine.txt", "r");
    if (file == NULL) return;

    fscanf(file, "%d\n", &user->routine.count);
    for (int i = 0; i < user->routine.count; i++)
    {
        fgets(user->routine.steps[i], sizeof(user->routine.steps[i]), file);
        user->routine.steps[i][strcspn(user->routine.steps[i], "\n")] = 0;
    }
    fclose(file);
}

// View routine
void viewRoutine(struct User user)
{
    printf("\nYour skincare routine:\n");
    for (int i = 0; i < user.routine.count; i++)
    {
        printf("%d. %s\n", i + 1, user.routine.steps[i]);
    }
}

// Add step
void addStep(struct User *user)
{
    if (user->routine.count >= MAX_STEPS)
    {
        printf("Routine full! Cannot add more steps.\n");
        return;
    }
    printf("Enter new step to add: ");
    getchar();
    fgets(user->routine.steps[user->routine.count], 100, stdin);
    user->routine.steps[user->routine.count][strcspn(user->routine.steps[user->routine.count], "\n")] = 0;
    user->routine.count++;
    saveRoutineToFile(*user);
    printf("Step added successfully!\n");
}

// Delete step
void deleteStep(struct User *user)
{
    int step;
    printf("Enter step number to delete: ");
    scanf("%d", &step);
    if (step < 1 || step > user->routine.count)
    {
        printf("Invalid step number!\n");
        return;
    }
    for (int i = step - 1; i < user->routine.count - 1; i++)
    {
        strcpy(user->routine.steps[i], user->routine.steps[i + 1]);
    }
    user->routine.count--;
    saveRoutineToFile(*user);
    printf("Step deleted successfully!\n");
}

// Update step
void updateStep(struct User *user)
{
    int step;
    printf("Enter step number to update: ");
    scanf("%d", &step);
    if (step < 1 || step > user->routine.count)
    {
        printf("Invalid step number!\n");
        return;
    }
    printf("Enter new step: ");
    getchar();
    fgets(user->routine.steps[step - 1], 100, stdin);
    user->routine.steps[step - 1][strcspn(user->routine.steps[step - 1], "\n")] = 0;
    saveRoutineToFile(*user);
    printf("Step updated successfully!\n");
}

// Search step
void searchStep(struct User user)
{
    char keyword[100];
    printf("Enter keyword to search: ");
    getchar();
    fgets(keyword, 100, stdin);
    keyword[strcspn(keyword, "\n")] = 0;

    int found = 0;
    for (int i = 0; i < user.routine.count; i++)
    {
        if (strstr(user.routine.steps[i], keyword))
        {
            printf("Found: Step %d -> %s\n", i + 1, user.routine.steps[i]);
            found = 1;
        }
    }
    if (!found)
    {
        printf("Keyword not found in routine.\n");
    }
}
